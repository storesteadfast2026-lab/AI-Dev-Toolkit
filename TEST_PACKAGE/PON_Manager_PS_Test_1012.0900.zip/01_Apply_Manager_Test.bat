@echo off
setlocal
echo ============================================================
echo APPLICATION OPERATIONS MANAGER PS - APPLY TEST
echo ============================================================
echo [INFO] Non-destructive test only.
powershell.exe -NoProfile -Command "Start-Sleep -Milliseconds 500"
echo [PASS] Live output stage 1/3
powershell.exe -NoProfile -Command "Start-Sleep -Milliseconds 500"
>&2 echo [WARN] Intentional STDERR line
powershell.exe -NoProfile -Command "Start-Sleep -Milliseconds 500"
echo [PASS] Live output stage 3/3
echo APPLY RESULT: PASS
echo ACTION RESULT: PASS
echo [INFO] Final PAUSE must be consumed automatically.
pause
echo [PASS] PAUSE acknowledgement received.
echo SCRIPT RESULT: PASS
exit /b 0
